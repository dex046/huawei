#include <stdio.h>
#include <iostream>
#include <string.h>
#include <vector>
#include <tuple>
#include <fstream>
#include <string>
#include <algorithm>
#include <limits.h>
#include <stdlib.h>
#include <sstream>
using namespace std;
#define MAX_SIZE 600
void DFS(vector<vector<vector<int>>> vec, vector<pair<int, int>> route, vector<int> src_des, string temp_route, vector<pair<string, int>> &res, int weight, int& min_weight, int flag)
{
    if(flag == 0)
    {
        for(int i = 0; i < vec[src_des[0]].size(); ++i)
        {
            if(vec[src_des[0]][i][2] == src_des[1])
            {
                weight += vec[src_des[0]][i][3];
                if(weight < min_weight)
                {
                    min_weight = weight;
                    temp_route = temp_route + (char)('0' + vec[src_des[0]][i][0]);
                    res.push_back({temp_route, weight});
                }
            }
        }
    }
    else
    {
        for(int i = 0; i < route.size(); ++i)
        {
            if(!route[i].second)
            {
                for(int j = 0; j < vec[src_des[0]].size(); ++j)
                {
                    if(vec[src_des[0]][j][2] == route[i].first)
                    {
                        weight += vec[src_des[0]][j][3];
                        if(weight > min_weight)
                        {
                            weight -= vec[src_des[0]][j][3];
                            continue;
                        }
                        string s = temp_route;
                        temp_route = temp_route + (char)('0' + vec[src_des[0]][j][0]) + "|";
                        int temp_src = src_des[0];
                        src_des[0] = route[i].first;
                        route[i].second = 1;
                        --flag;


                        DFS(vec, route, src_des, temp_route, res, weight, min_weight, flag);

                        temp_route = s;
                        src_des[0] = temp_src;
                        weight -= vec[src_des[0]][j][3];
                        route[i].second = 0;
                        ++flag;
                    }
                }
            }
        }
    }

//    int node = route.back();
//    for(int i = 0; i < route.size(); ++i)
//    {
//        for(int j = 0; j < vec[node].size(); ++j)
//        {
//            if(route[i] == vec[node][j][])
//            {

//            }
//        }
//    }



}
int main(int argc, char** argv)
{
    vector<vector<vector<int>>> vec;

    vec.reserve(50);
    vec.resize(50);
    for(int i =0; i < 50; ++i)
    {
        vec[i].reserve(50);
        for(int j = 0; j < 50; ++j)
        {
            vec[i][j].reserve(4);
        }
    }
    string str;
    ifstream fin;
    fin.open("VE.csv");

    string pattern = ",";
//cout << std::get<0>(vec[0][1]) << endl;
    while(fin >> str)
    {
        str += pattern;
        int size = str.size();
        //cout << str << endl;
        int pos = 0;
        vector<int> temp;
        for(int i = 0; i < size; ++i)
        {
            pos = str.find(pattern, i);
            if(pos < size)
            {
                string s = str.substr(i, pos - i);
                //cout << stoi(s) << " ";
                temp.push_back(stoi(s));
                i = pos + pattern.size() - 1;
            }
        }


//        cout << temp[1] << endl;
        vec[temp[1]].push_back(temp);
//        for(int i = 0; i < temp.size(); ++i)
//        {
//            cout << temp[i] << " ";
//        }
//        cout << endl;
    }
    fin.close();
    fin.clear();

    fin.open("route.csv");
    vector<int> src_des;
    vector<pair<int, int>> route;
    while(fin >> str)
    {
//        cout << str << endl;
        str += "|";
        int size = str.size();
        int pos = 0;
        for(int i = 0; i < size; ++i)
        {
            pos = str.find(pattern, i);
            if(pos < 0)
            {
                pos = str.find("|", i);
                if(pos < 0)
                {
                    break;
                }
                else if(pos < size)
                {
                    string s = str.substr(i, pos - i);
                    route.push_back({stoi(s), 0});
                    i = pos + pattern.size() - 1;
                }
            }
            else if(pos < size)
            {
                string s = str.substr(i, pos - i);
                src_des.push_back(stoi(s));
                i = pos + pattern.size() - 1;
            }
        }
    }
//    for(int i = 0; i < src_des.size(); ++i)
//    {
//        cout << src_des[i] << " ";
//    }
//    cout << endl;
//    for(int i = 0; i < route.size(); ++i)
//    {
//        cout << route[i].first << " ";
//    }
//    cout << endl;

//    for(int i = 0; i < vec.size(); ++i)
//    {
//        for(int j = 0; j < vec[i].size(); ++j)
//        {
//            for(int k = 0; k < vec[i][j].size(); ++k)
//            {
//                cout << vec[i][j][k] << " ";
//            }
//            cout << endl;
//        }
//    }


    vector<pair<string, int>> res;
    string temp_route = "";
    //temp_route.push_back(src_des[0]);
    int min_weight = INT_MAX;
    DFS(vec, route, src_des, temp_route, res, 0, min_weight, route.size());

//    cout << "fdsgds" << endl;
//    cout << res.size() << endl;
//    for(int i = 0; i < res.size(); ++i)
//    {
//        cout << res[i].first << endl;
//    }

    ofstream fout("result.csv");
    if(res.size() == 0)
    {
        fout << "NA" << endl;
    }
    else
    {
        fout << res[0].first << endl;
    }

    return 0;
}



//int main()
//{
//    int *num = new int[MAX_SIZE * 4], row = 0;
//    char *str = new char[8];
//    FILE *fp = fopen("test.csv", "r");
//    if(!fp)
//    {
//        printf("can't open file\n");
//        return -1;
//    }

//    while(!feof(fp))
//    {

//        fgets(str, 8, fp);
////        printf("%s\n", str);
////        cout << str << endl;
//        char *p;
//        const char* d = ",\n";
//        p = strtok(str, d);

//        int col = 0;
//        while(p)
//        {

//            num[row * 4 + col] = *p - '0';
////            cout << num[row * 4 + col] << " ";
//            p = strtok(NULL, d);
//        }
////        cout << endl;


//    }



//    fclose(fp);
//    return 0;
//}

